---

tags:

- PARA/Capture

---
> [Capture in the CODE model](https://lifeos.vip/guide/intro/second-brain.html#the-code-model)
## TASK

```LifeOS

TaskListByTag

```

  

## Bullet

```LifeOS

BulletListByTag

```