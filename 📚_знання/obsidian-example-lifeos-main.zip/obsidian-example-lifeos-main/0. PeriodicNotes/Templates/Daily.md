## Project List
%%A snapshot of the project today%%
<% LifeOS.Project.snapshot() %>

## Daily Record
%%Your Record%%

## Habit
%%Habit will not be counted as a task%%
- [ ] Drink a glass of water after wake up
- [ ] Breakfast
- Drink water
	- [ ] +1
	- [ ] +1
	- [ ] +1
	- [ ] +1
	- [ ] +1
	- [ ] +1
- [ ] English learning course
- [ ] Project time statistics
- [ ] Household accounting

## Energy allocation
%%Today's project list, according to the time consumed, automatic statistics project time consumed percentage%%
```LifeOS
ProjectListByTime
```

## Completed today
%%List of tasks completed today, extracted from all notes%%
```LifeOS
TaskDoneListByTime
```
