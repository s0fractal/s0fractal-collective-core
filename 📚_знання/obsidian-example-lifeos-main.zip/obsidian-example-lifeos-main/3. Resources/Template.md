## Task
%%Query tasks based on the tags field of the [Properties](https://help.obsidian.md/Editing+and+formatting/Properties) of the current file, extracted from all the notes%%
```LifeOS
TaskListByTag
```

## Bullet
%%Query bullets based on the tags field of the [Properties](https://help.obsidian.md/Editing+and+formatting/Properties) of the current file, extracted from all the notes%%
```LifeOS
BulletListByTag
```

## File
%%Query files based on the tags field of the [Properties](https://help.obsidian.md/Editing+and+formatting/Properties) of the current file, extracted from all the notes%%
```LifeOS
FileListByTag
```
