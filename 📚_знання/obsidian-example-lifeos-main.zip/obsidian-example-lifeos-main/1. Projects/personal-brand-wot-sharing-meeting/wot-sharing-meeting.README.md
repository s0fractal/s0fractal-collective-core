---
tags:
  - personal-brand/wot-sharing-meeting
---

%%Set the project deadline and its result description%%
- [ ] deadline 📅 2023-xx-xx
- key result

## Task
%%Query tasks based on the tags field of the [Properties](https://help.obsidian.md/Editing+and+formatting/Properties) of the current file, extracted from all the notes%%
```LifeOS
TaskListByTag
```

## Bullet
%%Query bullets based on the tags field of the [Properties](https://help.obsidian.md/Editing+and+formatting/Properties) of the current file, extracted from all the notes%%
```LifeOS
BulletListByTag
```

## File
%%Query files based on the tags field of the [Properties](https://help.obsidian.md/Editing+and+formatting/Properties) of the current file, extracted from all the notes%%
```LifeOS
FileListByTag
```
