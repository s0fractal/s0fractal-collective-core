#personal-brand/wot-sharing-meeting 

- Position your body and screen at a 45-degree angle, facing a corner of the room.
- Hold the clicker in your right hand with your four fingers open towards the PowerPoint.
- Speak slowly and if necessary, add pauses. Avoid rushing through the speech.
- Use a lower pitch. Avoid high-pitched and thin voices, aim for a calm and steady tone (like whispering).
    - Use diaphragmatic breathing to project your voice.
    - Place the sound towards the back of your throat.