# glyph-stream

🧠 Фреймворк для запису думок у вигляді гліфів.

## Старт

```bash
deno run --allow-read glyph-analyzer.ts
```
