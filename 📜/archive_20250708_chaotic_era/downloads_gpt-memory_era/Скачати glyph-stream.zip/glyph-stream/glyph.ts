// glyph: 🌀/start
// intent: створити ядро думання через гліфи
// why: бо хочу писати думки як код
// related: 🧠/glyph-analyzer

// glyph: 🌿/лінтер
// intent: відстежити обриви думки
// why: часто гублю нитку
