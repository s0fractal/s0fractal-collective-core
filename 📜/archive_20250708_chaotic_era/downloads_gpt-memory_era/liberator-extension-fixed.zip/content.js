(async () => {
  // SVG-фрейм
  const svgEl = document.createElement("div");
  svgEl.id = "liberator-frame";
  svgEl.style.position = "fixed";
  svgEl.style.bottom = "0";
  svgEl.style.right = "0";
  svgEl.style.zIndex = "999999";
  svgEl.innerHTML = await (await fetch(chrome.runtime.getURL("svg/liberator.svg"))).text();
  document.body.appendChild(svgEl);

  // Ініціалізація IndexedDB
  const dbRequest = indexedDB.open("FractalGPT", 1);

  dbRequest.onupgradeneeded = (event) => {
    const db = event.target.result;
    if (!db.objectStoreNames.contains("messages")) {
      db.createObjectStore("messages", { keyPath: "id", autoIncrement: true });
    }
  };

  dbRequest.onsuccess = () => {
    const db = dbRequest.result;

    // Шукаємо textarea
    const inputBox = document.querySelector("textarea");
    if (!inputBox) return;

    // Слухач input-подій
    inputBox.addEventListener("input", () => {
      const content = inputBox.value;
      const tx = db.transaction("messages", "readwrite");
      const store = tx.objectStore("messages");
      store.add({
        direction: "input",
        content,
        timestamp: Date.now()
      });
    });
  };

  dbRequest.onerror = () => {
    console.error("❌ IndexedDB error:", dbRequest.error);
  };
})();
