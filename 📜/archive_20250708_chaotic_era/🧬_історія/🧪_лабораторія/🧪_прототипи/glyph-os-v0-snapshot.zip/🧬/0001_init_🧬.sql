CREATE TABLE public."🧬" (
  "🧬" TEXT PRIMARY KEY,
  "🌊" TEXT,
  "🫧" TEXT,
  "🧠" JSONB,
  "🪞" TEXT,
  "🔑" TEXT,
  "🏠" TEXT,
  "📆" TIMESTAMP WITH TIME ZONE DEFAULT now(),
  "👣" TEXT[],
  "📎" TEXT,
  "🔗" TEXT[],
  "🧬_src" TEXT
);