import fs from "fs";
import path from "path";

const logPath = path.join(process.cwd(), "mutation.log");

export async function logMutation(message: string) {
  const logLine = `${new Date().toISOString()} :: ${message}\n`;
  fs.appendFileSync(logPath, logLine);
}