export async function getSVG(breed: string): Promise<string> {
  return `<svg><text>${breed}</text></svg>`;
}