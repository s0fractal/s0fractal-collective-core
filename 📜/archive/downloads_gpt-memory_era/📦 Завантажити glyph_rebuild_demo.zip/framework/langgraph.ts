export const graph = {
  rebuild: async ({ modify }) => {
    const currentGraph = {
      addNode: (name, fn) => console.log("Add node", name),
      setEdge: (from, to) => console.log("Redirect", from, "->", to)
    };
    modify(currentGraph);
    console.log("Graph rebuilt.");
  }
};