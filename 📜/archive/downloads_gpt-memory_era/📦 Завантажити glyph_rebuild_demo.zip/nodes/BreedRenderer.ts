import { getSVG } from "../lib/supabase";
import { logMutation } from "../lib/mutation";

let seenIntents: Record<string, number> = {};

export const BreedRenderer = async (state) => {
  const breed = state.glink || "🐩";
  seenIntents[breed] = (seenIntents[breed] || 0) + 1;

  if (seenIntents[breed] >= 3) {
    await logMutation(`Mutating ${breed} after 3x repeat`);
    state.triggerMutation = true;
  }

  return {
    ...state,
    output: await getSVG(breed),
  };
};