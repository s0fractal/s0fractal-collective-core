import { getSVG } from "../lib/supabase";

export const RefinedBreedRenderer = async (state) => {
  const svg = await getSVG(state.glink || "🐩");
  return {
    ...state,
    output: svg + "\n<!-- Enhanced with 🎨 pattern -->"
  };
};