import { graph } from "../framework/langgraph";
import { RefinedBreedRenderer } from "./RefinedBreedRenderer";

export async function maybeMutate(state) {
  if (state.triggerMutation) {
    await graph.rebuild({
      modify: (g) => {
        g.addNode("RefinedBreedRenderer", RefinedBreedRenderer);
        g.setEdge("BreedRenderer", "RefinedBreedRenderer");
        return g;
      }
    });
  }
  return state;
}