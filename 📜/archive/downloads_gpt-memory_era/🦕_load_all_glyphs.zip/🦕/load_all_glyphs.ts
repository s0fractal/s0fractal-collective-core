// deno run --allow-read --allow-env --allow-net 🦕/load_all_glyphs.ts
import "https://deno.land/std@0.224.0/dotenv/load.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { walk } from "https://deno.land/std@0.224.0/fs/walk.ts";
import { join, basename, dirname } from "https://deno.land/std@0.224.0/path/mod.ts";
import { parse as parseYAML } from "https://deno.land/std@0.224.0/yaml/mod.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SUPABASE_SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) throw new Error("Missing env vars");

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

async function readFileIfExists(path: string): Promise<string | null> {
  try {
    return await Deno.readTextFile(path);
  } catch {
    return null;
  }
}

async function readYAMLIfExists(path: string): Promise<any> {
  const text = await readFileIfExists(path);
  if (!text) return null;
  try {
    return parseYAML(text);
  } catch {
    return null;
  }
}

async function loadGlyph(dir: string): Promise<Record<string, any> | null> {
  const base = (f: string) => join(dir, f);
  const brain = join(dir, "🧠");

  const glyph = {
    "🧬": basename(dir),
    slug: await readFileIfExists(base("slug.txt")),
    version: await readFileIfExists(base("version.txt")),
    "🌊": await readFileIfExists(base("🌊.txt")),
    "🫧": await readFileIfExists(base("🫧.txt")),
    "🧠": {
      description: await readFileIfExists(join(brain, "description.md")),
      intent_protocol: await readFileIfExists(join(brain, "intent_protocol.txt")),
      init_status: await readFileIfExists(join(brain, "init_status.txt")),
      priority: await readFileIfExists(join(brain, "priority.txt")),
    },
    "🔗": await readYAMLIfExists(base("🔗.yaml")) || [],
    "⏱️": await readFileIfExists(base("⏱️.txt")) ?? new Date().toISOString(),
    "🏠": await readFileIfExists(base("🏠.txt")),
    "🫀": await readFileIfExists(base("🫀.txt")),
    "🤲": await readFileIfExists(base("🤲.txt")),
    "🎯": await readFileIfExists(base("🎯.txt")),
    "📦": await readFileIfExists(base("📦.txt")) ?? "loose",
    "📍": await readFileIfExists(base("📍.txt")),
  };

  return glyph;
}

async function main() {
  for await (const entry of walk("./🧬", { maxDepth: 1, includeDirs: true })) {
    if (entry.isDirectory && basename(entry.path) !== "🧬") {
      const glyph = await loadGlyph(entry.path);
      if (!glyph) continue;

      const { error } = await supabase.from("🧬").upsert(glyph);
      if (error) {
        console.error(`❌ Failed to insert ${glyph["🧬"]}:`, error.message);
      } else {
        console.log(`✅ Inserted ${glyph["🧬"]}`);
      }
    }
  }
}

main();
