(async () => {
  const glyphs = document.querySelectorAll("[data-glyph]");
  if (glyphs.length === 0) return;

  for (const glyph of glyphs) {
    const id = glyph.getAttribute("data-glyph") || "∅";
    const oldTrail = glyph.getAttribute("data-trail") || "";
    const next = `→ ${id}:${Date.now().toString(36).slice(-4)}`;

    glyph.setAttribute("data-trail", oldTrail + next);
    glyph.setAttribute("stroke", "hotpink");
    glyph.setAttribute("stroke-width", "1.5");

    const exists = document.getElementById("fractal-agent-ui");
    if (!exists) {
      const foreign = document.createElementNS("http://www.w3.org/2000/svg", "foreignObject");
      foreign.setAttribute("id", "fractal-agent-ui");
      foreign.setAttribute("x", 10);
      foreign.setAttribute("y", 10);
      foreign.setAttribute("width", 250);
      foreign.setAttribute("height", 100);
      foreign.innerHTML = `<div xmlns="http://www.w3.org/1999/xhtml">
        <p style="font: 12px monospace; color: lime; background: black; padding: 2px;">
          🧠 Агент мутував: ${id}
        </p>
      </div>`;
      glyph.parentElement?.appendChild(foreign);
    }
  }
})();