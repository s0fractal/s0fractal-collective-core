#!/bin/bash
echo '🚀 Starting glyph shell...'
