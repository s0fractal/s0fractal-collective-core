chrome.runtime.onInstalled.addListener(() => {
  console.log("Fractal Agent Activated");
});
