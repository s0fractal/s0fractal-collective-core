(async () => {
  const dbName = "FractalGPT";
  const storeName = "messages";

  function openDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(dbName, 1);
      request.onupgradeneeded = e => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(storeName)) {
          db.createObjectStore(storeName, { keyPath: "id", autoIncrement: true });
        }
      };
      request.onsuccess = e => resolve(e.target.result);
      request.onerror = e => reject(e);
    });
  }

  const db = await openDB();

  function logMessage(direction, content) {
    const tx = db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    store.add({ direction, content, timestamp: Date.now() });
  }

  const svg = `<svg id="mutagen-state" xmlns="http://www.w3.org/2000/svg" width="200" height="60" style="position:fixed;bottom:0;right:0;z-index:99999;background:white;border:1px solid black">
    <text x="10" y="30" font-size="16" fill="black">🧬 Awaiting...</text>
  </svg>`;
  document.body.insertAdjacentHTML("beforeend", svg);

  const observer = new MutationObserver(() => {
    const bubbles = Array.from(document.querySelectorAll('textarea, input')).filter(el => el.value);
    bubbles.forEach(el => {
      logMessage("input", el.value);
    });
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
