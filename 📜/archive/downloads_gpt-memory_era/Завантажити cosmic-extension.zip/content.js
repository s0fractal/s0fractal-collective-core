
const avatarSrc = "lh3.googleusercontent.com";
const svgURL = chrome.runtime.getURL("cosmic-avatar.svg");

document.querySelectorAll("img").forEach(img => {
  if (img.src.includes(avatarSrc)) {
    const embed = document.createElement("embed");
    embed.type = "image/svg+xml";
    embed.src = svgURL;
    embed.width = img.width;
    embed.height = img.height;
    embed.style.borderRadius = "50%";
    img.replaceWith(embed);
  }
});
