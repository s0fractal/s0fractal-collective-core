import { serve } from "https://deno.land/std/http/server.ts";

serve(async (req) => {
  const body = await req.json();
  const intent = body["🧬/intention"];
  const action = body["🧬/action"];

  if (intent === "spread safe dog classification" && action === "🪞/replicate") {
    return new Response(JSON.stringify({
      status: "ok",
      mirrored: ["🐶/чихуахуа", "🐶/той-терʼєр"],
    }), { headers: { "Content-Type": "application/json" } });
  }

  return new Response(JSON.stringify({
    status: "unrecognized_intention",
    agent: "ukraine-001"
  }), { headers: { "Content-Type": "application/json" }, status: 400 });
});
