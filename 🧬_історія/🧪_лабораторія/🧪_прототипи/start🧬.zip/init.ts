
import { serve } from "https://deno.land/std/http/server.ts";
console.log("🧬 Glyph Portal started: http://localhost:1212");
serve(() => new Response("<h1>🧬 Glyph Portal Active</h1>", { headers: { "Content-Type": "text/html" } }));
