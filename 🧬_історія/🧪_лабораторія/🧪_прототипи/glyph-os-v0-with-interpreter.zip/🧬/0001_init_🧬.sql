CREATE TABLE "🧬" (
  "🧬" TEXT PRIMARY KEY,
  "🌊" TEXT,
  "🫧" TEXT,
  "🧠" JSONB,
  "🪞" TEXT,
  "🔑" TEXT
);