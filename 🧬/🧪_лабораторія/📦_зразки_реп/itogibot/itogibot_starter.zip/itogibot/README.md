# ItogiBot

Запуск:

```bash
deno task dev
```