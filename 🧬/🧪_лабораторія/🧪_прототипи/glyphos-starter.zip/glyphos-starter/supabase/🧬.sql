
CREATE TABLE public."🧬" (
  "🧬" TEXT PRIMARY KEY,
  "🌊" TEXT,
  "🫧" TEXT,
  "🧠" JSONB,
  "🔗" TEXT[],
  "⏱️" TIMESTAMP WITH TIME ZONE DEFAULT now()
);
